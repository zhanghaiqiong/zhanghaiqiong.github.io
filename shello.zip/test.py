import tkinter as tk
from tkinter import *
import os
a=tk.Tk()
a.wm_title("教师节快乐！")
canvas=Canvas(a,width=300,height=300)
canvas.pack()
i=PhotoImage(file="")
canvas.create_image(50,50,anchor=NW,image=i)
b=tk.Label(a,text="哈哈哈哈")
b.pack()
def onClick():
    print("hello")
    os.system("")
c=tk.Button("明白明白",command=onClick)
c.pack(side=RIGHT)
a.mainloop()